print("What is your name?:")
username = input()
print("Hello " + username)