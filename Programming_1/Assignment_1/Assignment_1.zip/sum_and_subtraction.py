var1 = input ()
var1 = int ( var1 )

var2 = int ( input ())

if var1 > var2 :
   print (var1 - var2)
if var1 < var2 :
   print (var2 - var1)
if var1 == var2 :
   print (0)
   