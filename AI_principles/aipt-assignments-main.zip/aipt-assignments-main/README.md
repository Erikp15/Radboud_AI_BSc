# Artificial Intelligence: Principles & Techniques assignments

This repository contains the code templates and other information for the assignments of the course Artificial Intelligence: Principles & Techniques (SOW-BKI259) at the Radboud University Nijmegen. 

2024-2025